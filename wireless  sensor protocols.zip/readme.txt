This is a routing protocol in wireless sensor network.
We have worked under this domain to develop an energy efficient Routing Protocol.
We have combined the concepts of LEACH and PEGASIS Protocols
we also have used computational science - PARTICLE SWARM OPTIMIZATION for optimising it to global optimum
we have implemented all the concepts into an algorithm and executed in MATLAB
we have include LEACH AS WELL AS OUR PROTOCOL for relative study
